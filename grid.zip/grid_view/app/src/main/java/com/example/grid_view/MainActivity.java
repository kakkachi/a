package com.example.grid_view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    GridView gridView;
    String name[]={"one","two","three","four","five","six"};
    int picture[]={R.drawable.smile,R.drawable.sad,R.drawable.three,R.drawable.four,R.drawable.five,R.drawable.six};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView=(GridView) findViewById(R.id.gridview);
        BaseAdapter adapter=new BaseAdapter() {
            @Override
            public int getCount() {
                return name.length;
            }

            @Override
            public Object getItem(int position) {
                return null;
            }

            @Override
            public long getItemId(int position) {
                return 0;
            }

            @Override
            public View getView(int position, View view, ViewGroup parent) {
                if (view == null) {
                    view = getLayoutInflater().inflate(R.layout.grid_items, null);
                }
                ImageView imgageView=view.findViewById(R.id.imageview);
                TextView textView=view.findViewById(R.id.textview);
                imgageView.setImageResource(picture[position]);
                textView.setText(name[position]);
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String selected=name[position];
                        Toast.makeText(MainActivity.this, "selected fruit is"+selected, Toast.LENGTH_SHORT).show();
                    }
                });
                return view;
            }
        };
        gridView.setAdapter(adapter);


    }
}